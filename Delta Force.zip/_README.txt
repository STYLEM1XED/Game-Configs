Config files are located in.
Steam\steamapps\common\Delta Force Demo\Game\DeltaForce\Saved\Config\WindowsClient

-

Reflex is functional, although negatively impacts FPS and 1% lows.
This may improve once NVIDIA releases an updated driver with support for the game.
Leave this off unless you're using a very outdated GPU and experiencing significant latency issues.

-

Anti-aliasing now includes an in-game toggle to disable it, but it doesn't fully deactivate and requires additional configuration lines to enforce.
This is already applied if you're using my config.
If DLSS, FSR, or other upscaling methods are enabled, Anti-Aliasing will be automatically turned on.
To disable it again, simply turn off DLSS, FSR, or upscaling and restart the game.

-

Shaders can now be reloaded in game.